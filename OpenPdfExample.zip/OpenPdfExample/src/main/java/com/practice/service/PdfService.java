package com.practice.service;

public interface PdfService {

	void createPdf(String pdfname);

	void createPdfImage();

}
