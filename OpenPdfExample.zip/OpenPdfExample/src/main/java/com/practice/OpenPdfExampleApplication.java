package com.practice;

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
public class OpenPdfExampleApplication {

	public static void main(String[] args) {
		SpringApplication.run(OpenPdfExampleApplication.class, args);
	}

}
