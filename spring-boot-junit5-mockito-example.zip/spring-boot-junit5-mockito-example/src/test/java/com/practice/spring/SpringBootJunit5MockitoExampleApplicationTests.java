package com.practice.spring;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootJunit5MockitoExampleApplicationTests {

	@Test
	void contextLoads() {
	}

}
