package com.practice.encryption;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class SpringBootAsymmetricEncryptionWithRsaSender1ApplicationTests {

	@Test
	void contextLoads() {
	}

}
