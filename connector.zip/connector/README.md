# xepp-connector-lib
Library to connect and interact with DB
