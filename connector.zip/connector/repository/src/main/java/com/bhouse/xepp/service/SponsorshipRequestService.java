package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.SponsorshipRequestRepository;
import com.bhouse.xepp.connector.model.SponsorshipRequest;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.SponsorshipRequestPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SponsorshipRequestService {

    @Autowired
    private SponsorshipRequestRepository sponsorshipRequestRepository;

    /**
     *
     * @param srpojo
     * @return
     */
    public ResponseDTO saveSponsorshipRequest(SponsorshipRequestPojo srpojo){
        ResponseDTO dto = new ResponseDTO();
        SponsorshipRequest sr = sponsorshipRequestRepository.save(srpojo.convertToSponsorshipRequestModel(null, srpojo));
        dto.message = "Sponsorship request.";
        dto.data = sr;
        return dto;
    }

    /**
     *
     * @return
     */
    public ResponseDTO  getSponsorshipRequestList(){
        ResponseDTO dto = new ResponseDTO();
        List<SponsorshipRequest> list = sponsorshipRequestRepository.findAll();
        dto.message = "Sponsorship request list.";
        dto.data = list;
        return dto;
    }

    /**
     *
     * @param requestTrackingId
     * @return
     */
    public ResponseDTO getSponsorshipRequestById(String requestTrackingId){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipRequest> sr = sponsorshipRequestRepository.findById(requestTrackingId);
        if(sr.isPresent()){
            dto.message = "Sponsorship request details.";
            dto.data = sr.get();
        }else{
            dto.message = "Sponsorship request not found with id: " + requestTrackingId;
        }
        return dto;
    }

    /**
     *
     * @param srpojo
     * @return
     */
    public ResponseDTO updateSponsorshipRequest(SponsorshipRequestPojo srpojo){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipRequest> sr = sponsorshipRequestRepository.findById(srpojo.getRequestTrackingId());
        if(sr.isPresent()){
            SponsorshipRequest sponsorshipRequest = sponsorshipRequestRepository.save(srpojo.convertToSponsorshipRequestModel(sr.get(), srpojo));
            dto.message = "Sponsorship request updated.";
            dto.data = sponsorshipRequest;
        }else{
            dto.message = "Sponsorship request details not found with id: " + srpojo.getRequestTrackingId();
        }
        return dto;
    }

    /**
     *
     * @param requestTrackingId
     * @return
     */
    public ResponseDTO deleteSponsorshipRequestById(String requestTrackingId){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipRequest> sr = sponsorshipRequestRepository.findById(requestTrackingId);
        if(sr.isPresent()){
            sponsorshipRequestRepository.delete(sr.get());
            dto.message = "Sponsorship request deleted successfully.";
        }else{
            dto.message = "Sponsorship request details not found with id: " + requestTrackingId;
        }
        return dto;
    }
}
