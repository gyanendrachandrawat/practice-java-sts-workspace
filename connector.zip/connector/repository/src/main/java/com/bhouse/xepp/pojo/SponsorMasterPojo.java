package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.Address;
import com.bhouse.xepp.connector.model.SponsorMaster;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SponsorMasterPojo {

    private int id;
    private String sponsorIdentifier;
    private String sponsorType;
    private String firstName;
    private String lastName;
    private int addressId;
    private String businessName;
    private String contactMobile;
    private String contactEmail;
    private String createdBy;
    private String updatedBy;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getSponsorIdentifier() {
        return sponsorIdentifier;
    }

    public void setSponsorIdentifier(String sponsorIdentifier) {
        this.sponsorIdentifier = sponsorIdentifier;
    }

    public String getSponsorType() {
        return sponsorType;
    }

    public void setSponsorType(String sponsorType) {
        this.sponsorType = sponsorType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getContactMobile() {
        return contactMobile;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public SponsorMaster convertToSponsorMaster(SponsorMasterPojo sponsorMasterPojo){
        SponsorMaster sponsorMaster = new SponsorMaster();
        Address address = new Address();
        address.setId(sponsorMasterPojo.getAddressId());
        sponsorMaster.setAddressId(address);
        sponsorMaster.setBusinessName(sponsorMasterPojo.getBusinessName());
        sponsorMaster.setContactEmail(sponsorMasterPojo.getContactEmail());
        sponsorMaster.setContactMobile(sponsorMasterPojo.getContactMobile());
        sponsorMaster.setCreatedBy(sponsorMasterPojo.getCreatedBy());
        sponsorMaster.setCreatedDate(new Date());
        sponsorMaster.setFirstName(sponsorMasterPojo.getFirstName());
        sponsorMaster.setLastName(sponsorMasterPojo.getLastName());
        sponsorMaster.setSponsorType(sponsorMasterPojo.getSponsorType());
        sponsorMaster.setUpdatedBy(sponsorMasterPojo.getUpdatedBy());
        sponsorMaster.setUpdatedDate(new Date());
        return sponsorMaster;
    }

    public SponsorMaster updateSponsorMaster(SponsorMaster sponsorMaster, SponsorMasterPojo sponsorMasterPojo){
        if(sponsorMaster == null){
            sponsorMaster = new SponsorMaster();
        }
        if(sponsorMasterPojo.getAddressId() > 0){
            Address address = new Address();
            address.setId(sponsorMasterPojo.getAddressId());
            sponsorMaster.setAddressId(address);
        }
        if(sponsorMasterPojo.getBusinessName() != null && !sponsorMaster.getBusinessName().isEmpty()){
            sponsorMaster.setBusinessName(sponsorMasterPojo.getBusinessName());
        }
        if(sponsorMasterPojo.getContactEmail() != null && !sponsorMasterPojo.getContactEmail().isEmpty()){
            sponsorMaster.setContactEmail(sponsorMasterPojo.getContactEmail());
        }
        if(sponsorMasterPojo.getContactMobile() != null && !sponsorMasterPojo.getContactMobile().isEmpty()){
            sponsorMaster.setContactMobile(sponsorMasterPojo.getContactMobile());
        }
        if(sponsorMasterPojo.getCreatedBy()!= null && !sponsorMasterPojo.getCreatedBy().isEmpty()){
            sponsorMaster.setCreatedBy(sponsorMasterPojo.getCreatedBy());
            sponsorMaster.setCreatedDate(new Date());
        }
        if(sponsorMasterPojo.getFirstName() != null && !sponsorMasterPojo.getFirstName().isEmpty()){
            sponsorMaster.setFirstName(sponsorMasterPojo.getFirstName());
        }
        if(sponsorMasterPojo.getLastName() != null && !sponsorMasterPojo.getLastName().isEmpty()){
            sponsorMaster.setLastName(sponsorMasterPojo.getLastName());
        }
        if(sponsorMasterPojo.getSponsorType() != null && !sponsorMasterPojo.getSponsorType().isEmpty()){
            sponsorMaster.setSponsorType(sponsorMasterPojo.getSponsorType());
        }
        if(sponsorMasterPojo.getUpdatedBy() != null && !sponsorMasterPojo.getUpdatedBy().isEmpty()){
            sponsorMaster.setUpdatedBy(sponsorMasterPojo.getUpdatedBy());
            sponsorMaster.setUpdatedDate(new Date());
        }
        return sponsorMaster;
    }
}
