package com.bhouse.xepp.pojo;

import lombok.*;

import java.util.Date;

import com.bhouse.xepp.connector.model.Address;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class AddressPojo {

    private int id;
    private String addressOne;
    private String addressTwo;
    private String city;
    private String zip;
    private String state;
    private String county;
    private Date createdDate;
    private String createdBy;
    private String updatedBy;
    private Date updatedDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getAddressOne() {
        return addressOne;
    }

    public void setAddressOne(String addressOne) {
        this.addressOne = addressOne;
    }

    public String getAddressTwo() {
        return addressTwo;
    }

    public void setAddressTwo(String addressTwo) {
        this.addressTwo = addressTwo;
    }

    public String getCity() {
        return city;
    }

    public void setCity(String city) {
        this.city = city;
    }

    public String getZip() {
        return zip;
    }

    public void setZip(String zip) {
        this.zip = zip;
    }

    public String getState() {
        return state;
    }

    public void setState(String state) {
        this.state = state;
    }

    public String getCounty() {
        return county;
    }

    public void setCounty(String county) {
        this.county = county;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public Address convertToAddressModel(AddressPojo addressPojo){
        Address address = new Address();
        address.setId(addressPojo.getId());
        address.setAddressOne(addressPojo.getAddressOne());
        address.setAddressTwo(addressPojo.getAddressTwo());
        address.setCity(addressPojo.getCity());
        address.setCounty(addressPojo.getCounty());
        address.setCreatedBy(addressPojo.getCreatedBy());
        address.setCreatedDate(addressPojo.getCreatedDate());
        address.setState(addressPojo.getState());
        address.setUpdatedBy(addressPojo.getUpdatedBy());
        address.setUpdatedDate(addressPojo.getUpdatedDate());
        address.setZip(addressPojo.getZip());

        return address;
    }
}
