package com.bhouse.xepp.connector.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bhouse.xepp.connector.model.SponsorshipRequest;

public interface SponsorshipRequestRepository extends JpaRepository<SponsorshipRequest, String> {
}
