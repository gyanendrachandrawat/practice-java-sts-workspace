package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.SponsorshipRequest;
import com.bhouse.xepp.connector.model.SponsorshipRequestLog;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SponsorshipRequestLogPojo {

    private int sponsorRequestLogId;
    private String requestTrackingId;
    private String eventType;
    private String eventLog;
    private boolean publicAccess;
    private byte[] eventOutput;
    private String createdBy;

    public int getSponsorRequestLogId() {
        return sponsorRequestLogId;
    }

    public void setSponsorRequestLogId(int sponsorRequestLogId) {
        this.sponsorRequestLogId = sponsorRequestLogId;
    }

    public String getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(String requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventLog() {
        return eventLog;
    }

    public void setEventLog(String eventLog) {
        this.eventLog = eventLog;
    }

    public boolean isPublicAccess() {
        return publicAccess;
    }

    public void setPublicAccess(boolean publicAccess) {
        this.publicAccess = publicAccess;
    }

    public byte[] getEventOutput() {
        return eventOutput;
    }

    public void setEventOutput(byte[] eventOutput) {
        this.eventOutput = eventOutput;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public SponsorshipRequestLog convertToSponsorshipRequestModel(SponsorshipRequestLog srl, SponsorshipRequestLogPojo srlPojo){
        if(srl == null){
            srl = new SponsorshipRequestLog();
        }
        if(srlPojo.getSponsorRequestLogId() > 0){
            srl.setSponsorRequestLogId(srlPojo.getSponsorRequestLogId());
        }
        if(srlPojo.getEventLog() != null && !srlPojo.getEventLog().isEmpty()){
            srl.setEventLog(srlPojo.getEventLog());
        }
        if(srlPojo.getEventOutput() != null && srlPojo.getEventOutput().length > 0){
//            srl.setEventOutput(srlPojo.getEventOutput());
        }
        if(srlPojo.getEventType() != null && !srlPojo.getEventType().isEmpty()){
            srl.setEventType(srlPojo.getEventType());
        }
        srl.setPublicAccess(srlPojo.isPublicAccess());
        if(srlPojo.getCreatedBy() != null && !srlPojo.getCreatedBy().isEmpty()){
            srl.setCreatedBy(srlPojo.getCreatedBy());
            srl.setCreatedDate(new Date());
        }
        if(srlPojo.getRequestTrackingId() != null && !srlPojo.getRequestTrackingId().isEmpty()){
            SponsorshipRequest sponsorshipRequest = new SponsorshipRequest();
            sponsorshipRequest.setRequestTrackingId(srlPojo.getRequestTrackingId());
            srl.setRequestTrackingId(sponsorshipRequest);
        }

        return srl;
    }
}
