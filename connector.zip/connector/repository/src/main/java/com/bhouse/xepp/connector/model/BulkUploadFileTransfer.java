package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "BULK_UPLOAD_FILE_TRANSFER")
public class BulkUploadFileTransfer {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "FILE_TRANSFER_ID")
    private int fileTransferId;

    @Column(name = "FILE_NAME", length = 100)
    private String fileName;

    @ManyToOne(targetEntity = Status.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "STATUS_ID")
    private Status status;

    @Column(name="CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name="UPDATED_BY", length = 20)
    private String updatedBy;

    @Column(name="UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    @Column(name = "UPLOAD_USER_CATEGORY")
    private String uploadUserCategory;

    @ManyToOne(targetEntity = SponsorshipRequest.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "REQUEST_TRACKING_ID")
    private SponsorshipRequest requestTrackingId;

    public int getFileTransferId() {
        return fileTransferId;
    }

    public void setFileTransferId(int fileTransferId) {
        this.fileTransferId = fileTransferId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public String getUploadUserCategory() {
        return uploadUserCategory;
    }

    public void setUploadUserCategory(String uploadUserCategory) {
        this.uploadUserCategory = uploadUserCategory;
    }

    public SponsorshipRequest getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(SponsorshipRequest requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }
}
