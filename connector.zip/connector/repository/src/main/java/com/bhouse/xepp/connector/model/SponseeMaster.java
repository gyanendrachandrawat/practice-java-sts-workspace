package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "SPONSEE_MASTER")
public class SponseeMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "SPONSEE_ID")
    private int id;

    @Column(name = "FIRST_NAME", length = 20)
    private String firstName;

    @Column(name = "LAST_NAME", length = 20)
    private String lastName;

    @Column(name = "mobile", length = 15)
    private String mobile;

    @Column(name = "EMAIL", length = 50)
    private String email;

    @Column(name = "LANGUAGE_PREFERENCE", length = 10)
    private String languagePreference;

    @ManyToOne(targetEntity = Address.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "ADDRESS_ID")
    private Address address;

    @Column(name="CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name="UPDATED_BY", length = 20)
    private String updatedBy;

    @Column(name="UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    @ManyToOne(targetEntity = SponsorshipRequest.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "REQUEST_TRACKING_ID")
    private SponsorshipRequest requestTrackingId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLanguagePreference() {
        return languagePreference;
    }

    public void setLanguagePreference(String languagePreference) {
        this.languagePreference = languagePreference;
    }

    public Address getAddress() {
        return address;
    }

    public void setAddress(Address address) {
        this.address = address;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public SponsorshipRequest getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(SponsorshipRequest requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }
}
