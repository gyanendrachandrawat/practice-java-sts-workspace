package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.SponsorMaster;
import com.bhouse.xepp.connector.model.SponsorshipGroup;
import com.bhouse.xepp.connector.model.SponsorshipRequest;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SponsorshipRequestPojo {

    private String requestTrackingId;
    private int sponsorId;
    private int groupId;
    private String groupType;
    private String createdBy;

    public String getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(String requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    public int getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(int sponsorId) {
        this.sponsorId = sponsorId;
    }

    public int getGroupId() {
        return groupId;
    }

    public void setGroupId(int groupId) {
        this.groupId = groupId;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public SponsorshipRequest convertToSponsorshipRequestModel(SponsorshipRequest sr, SponsorshipRequestPojo srpojo){
        if(sr == null){
            sr = new SponsorshipRequest();
        }
        if(srpojo.getRequestTrackingId() != null && !srpojo.getRequestTrackingId().isEmpty()){
            sr.setRequestTrackingId(srpojo.getRequestTrackingId());
        }
        if(srpojo.getGroupId() > 0){
            SponsorshipGroup srgroup = new SponsorshipGroup();
            srgroup.setId(srpojo.getGroupId());
            sr.setGroupId(srgroup);
        }
        if(srpojo.getSponsorId() > 0){
            SponsorMaster smaster = new SponsorMaster();
            smaster.setId(srpojo.getSponsorId());
            sr.setSponsorId(smaster);
        }
        if(srpojo.getGroupType() != null && !srpojo.getGroupType().isEmpty()){
            sr.setGroupType(srpojo.getGroupType());
        }
        if(srpojo.getCreatedBy() != null && !srpojo.getCreatedBy().isEmpty()){
            sr.setCreatedBy(srpojo.getCreatedBy());
            sr.setCreatedDate(new Date());
        }
        return sr;
    }
}
