package com.bhouse.xepp.connector.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bhouse.xepp.connector.model.Address;

public interface AddressRepository extends JpaRepository<Address, Integer> {
}
