package com.bhouse.xepp.utils;

public class AppUtils {

    /**
     *
     * @param email
     * @return
     */
    public static boolean isValidEmail(String email){

        return false;
    }

    /**
     *
     * @param phone
     * @return
     */
    public static boolean isValidPhoneNumber(String phone){

        return false;
    }
}
