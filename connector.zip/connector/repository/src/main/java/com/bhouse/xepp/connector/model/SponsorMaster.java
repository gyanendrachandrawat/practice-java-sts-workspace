package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "SPONSOR_MASTER")
public class SponsorMaster {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="SPONSOR_ID")
    private int id;

//    @Column(name = "SPONSOR_IDENTIFIER", length = 20)
//    private String sponsorIdentifier;

    @Column(name = "SPONSOR_TYPE", length = 20)
    private String sponsorType;

    @Column(name = "FIRST_NAME", length = 20)
    private String firstName;

    @Column(name = "LAST_NAME", length = 20)
    private String lastName;

//    @ManyToOne(targetEntity = Address.class, cascade = CascadeType.ALL)
    @ManyToOne(targetEntity = Address.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "ADDRESS_ID")
    private Address addressId;

    @Column(name = "BUSINESS_NAME", length = 20)
    private String businessName;

    @Column(name = "CONTACT_MOBILE", length = 15)
    private String contactMobile;

    @Column(name = "CONTACT_EMAIL", length = 50)
    private String contactEmail;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name="CREATED_BY", nullable = false, length = 20)
    private String createdBy;

    @Column(name="UPDATED_BY", length = 20)
    private String updatedBy;

    @Column(name="UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

//    public String getSponsorIdentifier() {
//        return sponsorIdentifier;
//    }

//    public void setSponsorIdentifier(String sponsorIdentifier) {
//        this.sponsorIdentifier = sponsorIdentifier;
//    }

    public String getSponsorType() {
        return sponsorType;
    }

    public void setSponsorType(String sponsorType) {
        this.sponsorType = sponsorType;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public Address getAddressId() {
        return addressId;
    }

    public void setAddressId(Address addressId) {
        this.addressId = addressId;
    }

    public String getBusinessName() {
        return businessName;
    }

    public void setBusinessName(String businessName) {
        this.businessName = businessName;
    }

    public String getContactMobile() {
        return contactMobile;
    }

    public void setContactMobile(String contactMobile) {
        this.contactMobile = contactMobile;
    }

    public String getContactEmail() {
        return contactEmail;
    }

    public void setContactEmail(String contactEmail) {
        this.contactEmail = contactEmail;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

}
