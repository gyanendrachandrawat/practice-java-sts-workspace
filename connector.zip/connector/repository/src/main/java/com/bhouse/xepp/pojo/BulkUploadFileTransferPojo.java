package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.BulkUploadFileTransfer;
import com.bhouse.xepp.connector.model.SponsorshipRequest;
import com.bhouse.xepp.connector.model.Status;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class BulkUploadFileTransferPojo {

    private int fileTransferId;
    private String fileName;
    private int statusId;
    private String createdBy;
    private String updatedBy;
    private String uploadUserCategory;
    private String requestTrackingId;

    public int getFileTransferId() {
        return fileTransferId;
    }

    public void setFileTransferId(int fileTransferId) {
        this.fileTransferId = fileTransferId;
    }

    public String getFileName() {
        return fileName;
    }

    public void setFileName(String fileName) {
        this.fileName = fileName;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int status) {
        this.statusId = status;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getUploadUserCategory() {
        return uploadUserCategory;
    }

    public void setUploadUserCategory(String uploadUserCategory) {
        this.uploadUserCategory = uploadUserCategory;
    }

    public String getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(String requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    /**
     *
     * @param bulkUploadFileTransferPojo
     * @return
     */
    public BulkUploadFileTransfer convertToBulkUploadFileTransfer(BulkUploadFileTransfer buft, BulkUploadFileTransferPojo bulkUploadFileTransferPojo){
        if(buft == null){
            buft = new BulkUploadFileTransfer();
        }
        if(bulkUploadFileTransferPojo.getFileTransferId() > 0){
            buft.setFileTransferId(bulkUploadFileTransferPojo.getFileTransferId());
        }
        if(bulkUploadFileTransferPojo.getFileName() != null && !bulkUploadFileTransferPojo.getFileName().isEmpty()){
            buft.setFileName(bulkUploadFileTransferPojo.getFileName());
        }
        if(bulkUploadFileTransferPojo.getUploadUserCategory() != null && !bulkUploadFileTransferPojo.getUploadUserCategory().isEmpty()){
            buft.setUploadUserCategory(bulkUploadFileTransferPojo.getUploadUserCategory());
        }
        if(bulkUploadFileTransferPojo.getCreatedBy() != null && !bulkUploadFileTransferPojo.getCreatedBy().isEmpty()){
            buft.setCreatedBy(bulkUploadFileTransferPojo.getCreatedBy());
            buft.setCreatedDate(new Date());
        }
        if(bulkUploadFileTransferPojo.getUpdatedBy() != null && !bulkUploadFileTransferPojo.getUpdatedBy().isEmpty()){
            buft.setUpdatedBy(bulkUploadFileTransferPojo.getUpdatedBy());
            buft.setUpdatedDate(new Date());
        }
        if(bulkUploadFileTransferPojo.getRequestTrackingId() != null && !bulkUploadFileTransferPojo.getRequestTrackingId().isEmpty()){
            SponsorshipRequest sr = new SponsorshipRequest();
            sr.setRequestTrackingId(bulkUploadFileTransferPojo.getRequestTrackingId());
            buft.setRequestTrackingId(sr);
        }
        if(bulkUploadFileTransferPojo.getStatusId() > 0){
            Status status = new Status();
            status.setId(bulkUploadFileTransferPojo.getStatusId());
            buft.setStatus(status);
        }
        return buft;
    }

}
