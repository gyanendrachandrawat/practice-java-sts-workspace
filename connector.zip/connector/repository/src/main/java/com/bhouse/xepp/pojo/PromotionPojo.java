package com.bhouse.xepp.pojo;


import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.Promotion;
import com.bhouse.xepp.connector.model.SponsorshipRequest;
import com.bhouse.xepp.connector.model.Status;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class PromotionPojo {

    private int id;
    private String promoCode;
    private String promoPrefix;
    private String promoSuffix;
    private Date expirationDate;
    private int statusId;
    private String offerId;
    private String notificationMethod;
    private Date notifyDate;
    private String tag;
    private String createdBy;
    private String updatedBy;
    private String requestTrackingId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    public String getPromoPrefix() {
        return promoPrefix;
    }

    public void setPromoPrefix(String promoPrefix) {
        this.promoPrefix = promoPrefix;
    }

    public String getPromoSuffix() {
        return promoSuffix;
    }

    public void setPromoSuffix(String promoSuffix) {
        this.promoSuffix = promoSuffix;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public int getStatusId() {
        return statusId;
    }

    public void setStatusId(int statusId) {
        this.statusId = statusId;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getNotificationMethod() {
        return notificationMethod;
    }

    public void setNotificationMethod(String notificationMethod) {
        this.notificationMethod = notificationMethod;
    }

    public Date getNotifyDate() {
        return notifyDate;
    }

    public void setNotifyDate(Date notifyDate) {
        this.notifyDate = notifyDate;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(String requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    public Promotion convertToPromotion(PromotionPojo promotionPojo){
        Promotion promotion = new Promotion();
        System.out.println("======> " + promotionPojo.getId());
        if(promotionPojo.getId() > 0 ){
            promotion.setId(promotionPojo.getId());
        }
        System.out.println("======> " + promotion.getId());
        promotion.setCreatedBy(promotionPojo.getCreatedBy());
        promotion.setCreatedDate(new Date());
        promotion.setExpirationDate(promotionPojo.getExpirationDate());
        promotion.setNotificationMethod(promotionPojo.getNotificationMethod());
        promotion.setNotifyDate(promotionPojo.getNotifyDate());
        promotion.setOfferId(promotionPojo.getOfferId());
        promotion.setPromoCode(promotionPojo.getPromoCode());
        promotion.setPromoPrefix(promotionPojo.getPromoPrefix());
        promotion.setPromoSuffix(promotionPojo.getPromoSuffix());
        Status status = new Status();
        status.setId(promotionPojo.getId());
        promotion.setStatus(status);
        SponsorshipRequest sponsorshipRequest = new SponsorshipRequest();
        sponsorshipRequest.setRequestTrackingId(promotionPojo.getRequestTrackingId());
        promotion.setRequestTrackingId(sponsorshipRequest);
        promotion.setUpdatedBy(promotionPojo.getUpdatedBy());
        promotion.setUpdatedDate(new Date());

        return promotion;
    }

    public Promotion updatePromotionModel(Promotion promotion, PromotionPojo promotionPojo){
        if(promotionPojo.getExpirationDate() != null){
            promotion.setExpirationDate(promotionPojo.getExpirationDate());
        }
        if(promotionPojo.getNotificationMethod() != null){
            promotion.setNotificationMethod(promotionPojo.getNotificationMethod());
        }
        if(promotionPojo.getNotifyDate() != null){
            promotion.setNotifyDate(promotionPojo.getNotifyDate());
        }
        if(promotionPojo.getOfferId() != null && !promotionPojo.getOfferId().isEmpty()){
            promotion.setOfferId(promotionPojo.getOfferId());
        }
        if(promotionPojo.getPromoCode() != null && !promotionPojo.getPromoCode().isEmpty()){
            promotion.setPromoCode(promotionPojo.getPromoCode());
        }
        if(promotionPojo.getPromoPrefix() != null && !promotionPojo.getPromoPrefix().isEmpty()){
            promotion.setPromoPrefix(promotionPojo.getPromoPrefix());
        }
        if(promotionPojo.getPromoSuffix() != null && !promotionPojo.getPromoSuffix().isEmpty()){
            promotion.setPromoSuffix(promotionPojo.getPromoSuffix());
        }
        if(promotionPojo.getUpdatedBy() != null && !promotionPojo.getUpdatedBy().isEmpty()){
            promotion.setUpdatedBy(promotionPojo.getUpdatedBy());
            promotion.setUpdatedDate(new Date());
        }
        if(promotionPojo.getStatusId() > 0){
            Status status = new Status();
            status.setId(promotionPojo.getStatusId());
            promotion.setStatus(status);
        }
        if(promotionPojo.getRequestTrackingId() != null && !promotionPojo.getRequestTrackingId().isEmpty()){
            SponsorshipRequest requestTrackingId = new SponsorshipRequest();
            requestTrackingId.setRequestTrackingId(promotionPojo.getRequestTrackingId());
            promotion.setRequestTrackingId(requestTrackingId);
        }
        return promotion;
    }
}
