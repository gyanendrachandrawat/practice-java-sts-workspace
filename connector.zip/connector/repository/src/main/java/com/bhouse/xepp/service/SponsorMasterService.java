package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.SponsorMasterRepository;
import com.bhouse.xepp.connector.model.SponsorMaster;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.SponsorMasterPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SponsorMasterService {

    @Autowired
    private SponsorMasterRepository sponsorMasterRepository;

    public ResponseDTO saveSponsorMaster(SponsorMasterPojo sponsorMasterPojo){
        System.out.println("Save Sponsor Master...");
        ResponseDTO dto = new ResponseDTO();
        //check if address exists
        SponsorMaster sponsorMaster = sponsorMasterRepository.save(sponsorMasterPojo.convertToSponsorMaster(sponsorMasterPojo));
        dto.message = "Sponsor Saved Successfully.";
        dto.data = sponsorMaster;
        return dto;
    }

    public ResponseDTO getSponsorById(int sponsorId){
        System.out.println("Get Sponsor Master using ID...");
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorMaster> sponsorMaster = sponsorMasterRepository.findById(sponsorId);
        dto.message = "Sponsor Details";
        dto.data = sponsorMaster;
        return dto;
    }

    public ResponseDTO getSponsorMasterList(){
        System.out.println("Get Sponsor Master using ID...");
        ResponseDTO dto = new ResponseDTO();
        List<SponsorMaster> sponsorMasterList = sponsorMasterRepository.findAll();
        dto.message = "Sponsor Details";
        dto.data = sponsorMasterList;
        return dto;
    }

    public ResponseDTO updateSponsorMaster(SponsorMasterPojo sponsorMasterPojo){
        ResponseDTO dto = new ResponseDTO();
        //check if sponsor master exists in db, if exists then delete
        Optional<SponsorMaster> sponsorMaster = sponsorMasterRepository.findById(sponsorMasterPojo.getId());
        if(sponsorMaster.isPresent()){
            SponsorMaster sm = sponsorMasterRepository.save(sponsorMasterPojo.updateSponsorMaster(sponsorMaster.get(), sponsorMasterPojo));
            dto.message = "Sponsor Master updated successfully.";
        } else {
            dto.message = "No Sponsor Master Details exists with id: " + sponsorMasterPojo.getId();
        }
        return dto;
    }

    public ResponseDTO deleteSponsorMasterById(int sponsorId){
        System.out.println("Delete sponsor master by id: " + sponsorId);
        ResponseDTO dto = new ResponseDTO();
        //check if sponsor master exists in db, if exists then delete
        Optional<SponsorMaster> sponsorMaster = sponsorMasterRepository.findById(sponsorId);
        if(sponsorMaster.isPresent()){
            sponsorMasterRepository.delete(sponsorMaster.get());
            dto.message = "Sponsor Master deleted successfully.";
        } else {
            dto.message = "No Sponsor Master Details exists with id: " + sponsorId;
        }
        return dto;
    }

}
