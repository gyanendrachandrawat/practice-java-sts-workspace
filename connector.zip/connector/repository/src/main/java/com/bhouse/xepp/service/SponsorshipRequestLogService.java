package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.SponsorshipRequestLogRepository;
import com.bhouse.xepp.connector.model.SponsorshipRequestLog;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.SponsorshipRequestLogPojo;

import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SponsorshipRequestLogService {

    private SponsorshipRequestLogRepository sponsorshipRequestLogRepository;

    /**
     *
     * @param srlPojo
     * @return
     */
    public ResponseDTO saveSponsorshipRequestLog(SponsorshipRequestLogPojo srlPojo){
        ResponseDTO dto = new ResponseDTO();
        SponsorshipRequestLog srl = sponsorshipRequestLogRepository.save(srlPojo.convertToSponsorshipRequestModel(null, srlPojo));
        dto.message = "Sponsorship request log. ";
        dto.data = srl;
        return dto;
    }

    /**
     *
     * @return
     */
    public ResponseDTO getSponsorshipRequestLogList(){
        ResponseDTO dto = new ResponseDTO();
        List<SponsorshipRequestLog> srlList = sponsorshipRequestLogRepository.findAll();
        dto.message = "Sponsorship request log list";
        dto.data = srlList;
        return dto;
    }

    /**
     *
     * @param requestLogId
     * @return
     */
    public ResponseDTO getSponsorshipRequestLogById(int requestLogId){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipRequestLog> srl = sponsorshipRequestLogRepository.findById(requestLogId);
        if(srl.isPresent()){
            dto.message = "Sponsorship request log.";
            dto.data = srl.get();
        }else{
            dto.message = "No data found with the id: " + requestLogId;
        }
        return dto;
    }

    /**
     *
     * @param srlPojo
     * @return
     */
    public ResponseDTO updateSponsorshipRequestLog(SponsorshipRequestLogPojo srlPojo){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipRequestLog> srl = sponsorshipRequestLogRepository.findById(srlPojo.getSponsorRequestLogId());
        if(srl.isPresent()){
            SponsorshipRequestLog srlog = sponsorshipRequestLogRepository.save(srlPojo.convertToSponsorshipRequestModel(srl.get(), srlPojo));
            dto.message = "Sponsorship request log updated successfully.";
            dto.data = srlog;
        }else{
            dto.message = "No data found with the id: " + srlPojo.getSponsorRequestLogId();
        }
        return dto;
    }

    /**
     *
     * @param requestLogId
     * @return
     */
    public ResponseDTO deleteSponsorshipRequestLogById(int requestLogId){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipRequestLog> srl = sponsorshipRequestLogRepository.findById(requestLogId);
        if(srl.isPresent()){
            sponsorshipRequestLogRepository.delete(srl.get());
            dto.message = "Sponsorship request log deleted successfully.";
        }else{
            dto.message = "No data found with the id: " + requestLogId;
        }
        return dto;
    }
}
