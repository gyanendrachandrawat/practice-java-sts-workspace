package com.bhouse.xepp.connector.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;
import static org.mockito.Mockito.times;
import static org.mockito.Mockito.when;

import java.util.ArrayList;
import java.util.Date;
import java.util.List;
import java.util.Optional;

import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;
import org.mockito.InjectMocks;
import org.mockito.Mock;
import org.mockito.Mockito;
import org.mockito.MockitoAnnotations;

import com.bhouse.xepp.connector.dao.AddressRepository;
import com.bhouse.xepp.connector.model.Address;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.AddressPojo;
import com.bhouse.xepp.service.AddressService;

class AddressServiceTest {

	@InjectMocks
	private AddressService addressService;

	@Mock
	private AddressRepository addressRepositoryMock;

	@BeforeEach
	public void setup() {
		MockitoAnnotations.initMocks(this);
	}

	@Test
	void testSaveAddress() {
		Address address = new Address(1, "South Mumbai", "South", "MUMBAI", "451521", "MAHARASHTRA", "India", "Adam",
				new Date(25), "Adam", new Date(26));
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.data = address;
		responseDTO.message = "Address Saved Successfully.";
		AddressPojo addressPojo = new AddressPojo(1, "South Mumbai", "South", "MUMBAI", "451521", "MAHARASHTRA",
				"India", new Date(25), "Adam", "Adam", new Date(26));

		when(addressRepositoryMock.save(Mockito.any())).thenReturn(address);
		ResponseDTO responseDTO2 = addressService.saveAddress(addressPojo);
		assertEquals(responseDTO.data, responseDTO2.data);
	}

	@Test
	void testGetAddressList() {
		Address address = new Address(1, "South Mumbai", "South", "MUMBAI", "451521", "MAHARASHTRA", "India", "Adam",
				new Date(25), "Adam", new Date(26));
		List<Address> addressList = new ArrayList<Address>();
		addressList.add(address);
		ResponseDTO responseDTO = new ResponseDTO();
		responseDTO.data = addressList;
		responseDTO.message = "Address List";

		when(addressRepositoryMock.findAll()).thenReturn(addressList);
		ResponseDTO responseDTO2 = addressService.getAddressList();
		assertEquals(responseDTO.data, responseDTO2.data);
	}

	@Test
	void testgetAddressById() {
		Address address = new Address(1, "South Mumbai", "South", "MUMBAI", "451521", "MAHARASHTRA", "India", "Adam",
				new Date(25), "Adam", new Date(26));
		Optional<Address> address1 = Optional.of(address);
		int addressId = 1;
		ResponseDTO dto = new ResponseDTO();
		dto.data = address;
		dto.message = "Address details";
		when(addressRepositoryMock.findById(Mockito.anyInt())).thenReturn(address1);
		ResponseDTO responseDTO2 = addressService.getAddressById(addressId);
		assertEquals(Optional.of(dto.data), responseDTO2.data);
	}

	@Test
	void testupdateAddress() {
		ResponseDTO dto = null;
		assertEquals(addressService.updateAddress(), dto);
	}

	@Test
	void testdeleteAddressByIdWhenIdFound() {
		Address address = new Address(1, "South Mumbai", "South", "MUMBAI", "451521", "MAHARASHTRA", "India", "Adam",
				new Date(25), "Adam", new Date(26));
		ResponseDTO dto = new ResponseDTO();
		Optional<Address> addressOptional = Optional.of(address);
		when(addressRepositoryMock.findById(Mockito.anyInt())).thenReturn(addressOptional);
		ResponseDTO dto2 = addressService.deleteAddressById(address.getId());
		Mockito.verify(addressRepositoryMock, times(1)).delete(address);
		dto.message = "Address deleted successfully by id: " + address.getId();
		assertEquals(dto2.message, dto.message);
	}

	@Test
	void testdeleteAddressByIdWhenIdNotFound() {
		Address address = new Address();
		ResponseDTO dto = new ResponseDTO();
		Optional<Address> addressOptional = Optional.empty();
		when(addressRepositoryMock.findById(Mockito.anyInt())).thenReturn(addressOptional);
		ResponseDTO dto2 = addressService.deleteAddressById(address.getId());
		dto.message = "No Address found with given id: " + address.getId();
		System.out.println(dto2.message + "    " + dto.message);
		assertEquals(dto2.message, dto.message);
	}
}
