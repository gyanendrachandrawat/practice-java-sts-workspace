package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.SponsorMaster;
import com.bhouse.xepp.connector.model.SponsorshipGroup;

@Data
@NoArgsConstructor
@AllArgsConstructor
@ToString
public class SponsorshipGroupPojo {

    private String groupName;
    private String groupDescription;
    private int sponsorId;
    private String createdBy;
    private String updatedBy;

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDescription() {
        return groupDescription;
    }

    public void setGroupDescription(String groupDescription) {
        this.groupDescription = groupDescription;
    }

    public int getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(int sponsorId) {
        this.sponsorId = sponsorId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }


    public SponsorshipGroup convertToSponsorshipGroup(SponsorshipGroupPojo sponsorshipGroupPojo){
        SponsorshipGroup sponsorshipGroup = new SponsorshipGroup();
        sponsorshipGroup.setGroupName(sponsorshipGroupPojo.getGroupName());
        sponsorshipGroup.setGroupDescription(sponsorshipGroupPojo.getGroupDescription());
        SponsorMaster smaster = new SponsorMaster();
        smaster.setId(sponsorshipGroupPojo.getSponsorId());
        sponsorshipGroup.setSponsorId(smaster);
        sponsorshipGroup.setCreatedBy(sponsorshipGroupPojo.getCreatedBy());
        sponsorshipGroup.setCreatedDate(new Date());
        sponsorshipGroup.setUpdatedBy(sponsorshipGroupPojo.getUpdatedBy());
        sponsorshipGroup.setUpdatedDate(new Date());
        return sponsorshipGroup;
    }
}
