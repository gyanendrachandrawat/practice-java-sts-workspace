package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "SPONSORSHIP_REQUEST")
public class SponsorshipRequest {

    @Id
    @Column(name = "REQUEST_TRACKING_ID", nullable = false)
    private String requestTrackingId;

    @ManyToOne(targetEntity = SponsorMaster.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "SPONSOR_ID", nullable = false)
    private SponsorMaster sponsorId;

    @ManyToOne(targetEntity = SponsorshipGroup.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "GROUP_ID", nullable = false)
    private SponsorshipGroup groupId;

    @Column(name = "GROUP_TYPE", length = 20)
    private String groupType;

    @Column(name="CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    public String getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(String requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    public SponsorMaster getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(SponsorMaster sponsorId) {
        this.sponsorId = sponsorId;
    }

    public SponsorshipGroup getGroupId() {
        return groupId;
    }

    public void setGroupId(SponsorshipGroup groupId) {
        this.groupId = groupId;
    }

    public String getGroupType() {
        return groupType;
    }

    public void setGroupType(String groupType) {
        this.groupType = groupType;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
}
