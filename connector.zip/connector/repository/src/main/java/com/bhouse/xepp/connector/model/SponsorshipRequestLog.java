package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.sql.Blob;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "SPONSORSHIP_REQUEST_LOG")
public class SponsorshipRequestLog {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "SPONSOR_REQUEST_LOG_ID")
    private int sponsorRequestLogId;

    @ManyToOne(targetEntity = SponsorshipRequest.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "REQUEST_TRACKING_ID")
    private SponsorshipRequest requestTrackingId;

    @Column(name = "EVENT_TYPE", length = 20)
    private String eventType;

    @Column(name = "EVENT_LOG", length = 100)
    private String eventLog;

    @Column(name = "PUBLIC_ACCESS", columnDefinition = "TINYINT", length = 1)
    private boolean publicAccess;

    @Column(name = "EVENT_OUTPUT")
    private Blob eventOutput;

    @Column(name="CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    public int getSponsorRequestLogId() {
        return sponsorRequestLogId;
    }

    public void setSponsorRequestLogId(int sponsorRequestLogId) {
        this.sponsorRequestLogId = sponsorRequestLogId;
    }

    public SponsorshipRequest getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(SponsorshipRequest requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    public String getEventType() {
        return eventType;
    }

    public void setEventType(String eventType) {
        this.eventType = eventType;
    }

    public String getEventLog() {
        return eventLog;
    }

    public void setEventLog(String eventLog) {
        this.eventLog = eventLog;
    }

    public boolean isPublicAccess() {
        return publicAccess;
    }

    public void setPublicAccess(boolean publicAccess) {
        this.publicAccess = publicAccess;
    }

    public Blob getEventOutput() {
        return eventOutput;
    }

    public void setEventOutput(Blob eventOutput) {
        this.eventOutput = eventOutput;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }
}
