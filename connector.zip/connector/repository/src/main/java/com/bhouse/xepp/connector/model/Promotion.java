package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "PROMOTION")
public class Promotion {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name = "PROMO_ID")
    private int id;

    @Column(name = "PROMO_CODE", length = 20)
    private String promoCode;

    @Column(name = "PROMO_PREFIX", length = 20)
    private String promoPrefix;

    @Column(name = "PROMO_SUFFIX", length = 20)
    private String promoSuffix;

    @Column(name = "EXPIRATION_DATE")
    private Date expirationDate;

    @ManyToOne(targetEntity = Status.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "STATUS_ID")
    private Status status;

    @Column(name = "OFFER_ID", length = 20)
    private String offerId;

    @Column(name = "NOTIFICATION_METHOD", length = 20)
    private String notificationMethod;

    @Column(name = "NOTIFY_DATE")
    private Date notifyDate;

    @Column(name = "TAG", length = 20)
    private String tag;

    @Column(name="CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name="UPDATED_BY", length = 20)
    private String updatedBy;

    @Column(name="UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    @ManyToOne(targetEntity = SponsorshipRequest.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "REQUEST_TRACKING_ID")
    private SponsorshipRequest requestTrackingId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getPromoCode() {
        return promoCode;
    }

    public void setPromoCode(String promoCode) {
        this.promoCode = promoCode;
    }

    public String getPromoPrefix() {
        return promoPrefix;
    }

    public void setPromoPrefix(String promoPrefix) {
        this.promoPrefix = promoPrefix;
    }

    public String getPromoSuffix() {
        return promoSuffix;
    }

    public void setPromoSuffix(String promoSuffix) {
        this.promoSuffix = promoSuffix;
    }

    public Date getExpirationDate() {
        return expirationDate;
    }

    public void setExpirationDate(Date expirationDate) {
        this.expirationDate = expirationDate;
    }

    public Status getStatus() {
        return status;
    }

    public void setStatus(Status status) {
        this.status = status;
    }

    public String getOfferId() {
        return offerId;
    }

    public void setOfferId(String offerId) {
        this.offerId = offerId;
    }

    public String getNotificationMethod() {
        return notificationMethod;
    }

    public void setNotificationMethod(String notificationMethod) {
        this.notificationMethod = notificationMethod;
    }

    public Date getNotifyDate() {
        return notifyDate;
    }

    public void setNotifyDate(Date notifyDate) {
        this.notifyDate = notifyDate;
    }

    public String getTag() {
        return tag;
    }

    public void setTag(String tag) {
        this.tag = tag;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }

    public SponsorshipRequest getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(SponsorshipRequest requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }
}
