package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.PromotionRepository;
import com.bhouse.xepp.connector.model.Promotion;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.PromotionPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class PromotionService {

    @Autowired
    private PromotionRepository promotionRepository;

    public ResponseDTO savePromotion(PromotionPojo promotionPojo){
        ResponseDTO dto = new ResponseDTO();
        Promotion promotion = promotionRepository.save(promotionPojo.convertToPromotion(promotionPojo));
        dto.message = "Promotion Saved Successfully.";
        dto.data = promotion;
        return dto;
    }

    public ResponseDTO getPromotionList(){
        ResponseDTO dto = new ResponseDTO();
        List<Promotion> promotion = promotionRepository.findAll();
        dto.message = "Promotion List";
        dto.data = promotion;
        return dto;
    }

    public ResponseDTO getPromotionById(int promotionId){
        ResponseDTO dto = new ResponseDTO();
        Optional<Promotion> promotion = promotionRepository.findById(promotionId);
        if(promotion.isPresent()){
            dto.message = "Promotion Details.";
            dto.data = promotion.get();
        }else{
            dto.message = "No Promotion details exists with the id: " + promotionId;
        }
        return dto;
    }

    public ResponseDTO updatePromotion(PromotionPojo promotionPojo){
        ResponseDTO dto = new ResponseDTO();
        //get promotion data and update the values with the new values
        Optional<Promotion> promotion = promotionRepository.findById(promotionPojo.getId());
        if(promotion.isPresent()){
            Promotion promo = promotionRepository.save(promotionPojo.updatePromotionModel(promotion.get(), promotionPojo));
            dto.message = "Promotion details updated successfully.";
            dto.data = promo;
        }else{
            dto.message = "No Promotion details exists with the id: " + promotionPojo.getId();
        }
        return dto;
    }

    public ResponseDTO deletePromotionById(int promotionId){
        ResponseDTO dto = new ResponseDTO();
        //check if promotion exists in db, then delete
        Optional<Promotion> promotion = promotionRepository.findById(promotionId);
        if(promotion.isPresent()){
            promotionRepository.delete(promotion.get());
            dto.message = "Promotion deleted successfully.";
        }else{
            dto.message = "No Promotion details exists with the id: " + promotionId;
        }
        return dto;
    }
}
