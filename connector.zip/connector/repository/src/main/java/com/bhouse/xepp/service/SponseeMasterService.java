package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.SponseeMasterRepository;
import com.bhouse.xepp.connector.model.SponseeMaster;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.SponseeMasterPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SponseeMasterService {

    @Autowired
    private SponseeMasterRepository sponseeMasterRepository;

    /**
     *
     * @param sponseeMasterPojo
     * @return
     */
    public ResponseDTO saveSponseeMaster(SponseeMasterPojo sponseeMasterPojo) {
        ResponseDTO dto = new ResponseDTO();
        dto.message = "Sponsee Master";
        SponseeMaster smaster = sponseeMasterRepository.save(sponseeMasterPojo.convertToSponseeMasterModel(null, sponseeMasterPojo));
        dto.data = smaster;
        return dto;
    }

    /**
     *
     * @param id
     * @return
     */
    public ResponseDTO getSponseeMasterById(int id) {
        ResponseDTO dto = new ResponseDTO();
        dto.message = "Sponsee Master Details";
        Optional<SponseeMaster> smaster = sponseeMasterRepository.findById(id);
        if(smaster.isPresent()) {
            dto.data = smaster.get();
        }
        return dto;
    }

    /**
     *
     * @return
     */
    public ResponseDTO getSponseeMasterList() {
        ResponseDTO dto = new ResponseDTO();
        dto.message = "Sponsee Masters list";
        List<SponseeMaster> smaster = sponseeMasterRepository.findAll();
        if(!smaster.isEmpty()) {
            dto.data = smaster;
        }
        return dto;
    }

    /**
     *
     * @param sponseeMasterPojo
     * @return
     */
    public  ResponseDTO updateSponseeMaster(SponseeMasterPojo sponseeMasterPojo){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponseeMaster> sponseeMaster = sponseeMasterRepository.findById(sponseeMasterPojo.getId());
        if(sponseeMaster.isPresent()){
            dto.data = sponseeMasterRepository.save(sponseeMasterPojo.convertToSponseeMasterModel(sponseeMaster.get(), sponseeMasterPojo));
            dto.message = "Sponsee updated successfully";
        }else{
            dto.message = "Sponsee doesn't exist with the id: " + sponseeMasterPojo.getId();
        }
        return dto;
    }

    /**
     *
     * @param sponseeId
     * @return
     */
    public  ResponseDTO deleteSponseeMasterById(int sponseeId){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponseeMaster> sponseeMaster = sponseeMasterRepository.findById(sponseeId);
        if(sponseeMaster.isPresent()){
            sponseeMasterRepository.delete(sponseeMaster.get());
            dto.message = "Sponsee updated successfully";
        }else{
            dto.message = "Sponsee doesn't exist with the id: " + sponseeId;
        }
        return dto;
    }
}
