package com.bhouse.xepp.connector.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bhouse.xepp.connector.model.Promotion;

public interface PromotionRepository extends JpaRepository<Promotion, Integer> {
}
