package com.bhouse.xepp.connector.model.test;

import static org.junit.jupiter.api.Assertions.assertEquals;

import java.util.Date;
import org.junit.jupiter.api.AfterEach;
import org.junit.jupiter.api.BeforeEach;
import org.junit.jupiter.api.Test;

import com.bhouse.xepp.connector.model.Address;

class AddressTest {

		public static final int expected_id = 1;
		public static final String expected_addressOne = "South Mumbai";
		public static final String expected_addressTwo = "South";
		public static final String expected_city = "MUMBAI";
		public static final String expected_zip = "451521";
		public static final String expected_state = "MAHARASHTRA";
		public static final String expected_county = "India";
		public static final String expected_createdBy = "Adam";
		public static final Date expected_createdDate = new Date(25);
		public static final String expected_updatedBy = "Adam";
		public static final Date expected_updatedDate = new Date(26);

		private Address address;

		@BeforeEach
		public void setUp() throws Exception {
			address = new Address(1, "South Mumbai", "South", "MUMBAI", "451521", "MAHARASHTRA", "India", "Adam",
					new Date(25), "Adam", new Date(26));
		}

		@AfterEach
		public void tearDown() throws Exception {
			System.out.println("Test Completed");

		}

		@Test
		void testAddressDetails() throws Exception  {
			assertEquals(expected_id, address.getId());
			assertEquals(expected_addressOne, address.getAddressOne());
			assertEquals(expected_addressTwo, address.getAddressTwo());
			assertEquals(expected_city, address.getCity());
			assertEquals(expected_zip, address.getZip());
			assertEquals(expected_state, address.getState());
			assertEquals(expected_county, address.getCounty());
			assertEquals(expected_createdDate, address.getCreatedDate());
			assertEquals(expected_createdBy, address.getCreatedBy());
			assertEquals(expected_updatedDate, address.getUpdatedDate());
			assertEquals(expected_updatedBy, address.getUpdatedBy());
		}
}
