package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.StatusRepository;
import com.bhouse.xepp.connector.model.Status;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.StatusPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class StatusService {

    @Autowired
    private StatusRepository statusRepository;

    /**
     *
     * @param statusPojo
     * @return
     */
    public ResponseDTO saveStatus(StatusPojo statusPojo){
        ResponseDTO dto = new ResponseDTO();
        Status status = statusRepository.save(statusPojo.convertToStatusModel(null, statusPojo));
        dto.message = "Status saved successfully.";
        dto.data = status;
        return dto;
    }

    /**
     *
     * @return
     */
    public ResponseDTO getStatusList(){
        ResponseDTO dto = new ResponseDTO();
        List<Status> statusList = statusRepository.findAll();
        dto.message = "Status List.";
        dto.data = statusList;
        return dto;
    }

    /**
     *
     * @param statusId
     * @return
     */
    public ResponseDTO getStatusById(int statusId){
        ResponseDTO dto = new ResponseDTO();
        Optional<Status> status = statusRepository.findById(statusId);
        if(status.isPresent()){
            dto.message = "Status details.";
            dto.data = status.get();
        }else{
            dto.message = "Status not found with the id: " + statusId;
        }
        return dto;
    }

    public ResponseDTO updateStatus(StatusPojo statusPojo){
        ResponseDTO dto = new ResponseDTO();
        Optional<Status> status = statusRepository.findById(statusPojo.getId());
        if(status.isPresent()){
            Status st = statusRepository.save(statusPojo.convertToStatusModel(status.get(), statusPojo));
            dto.message = "Status details updated.";
            dto.data = st;
        }else{
            dto.message = "Status not found with the id: " + statusPojo.getId();
        }
        return dto;
    }

    /**
     *
     * @param statusId
     * @return
     */
    public ResponseDTO deleteStatusById(int statusId){

        ResponseDTO dto = new ResponseDTO();
        Optional<Status> status = statusRepository.findById(statusId);
        if(status.isPresent()){
            statusRepository.delete(status.get());
            dto.message = "Status deleted successfully.";
        }else{
            dto.message = "Status not found with the id: " + statusId;
        }
        return dto;
    }
}
