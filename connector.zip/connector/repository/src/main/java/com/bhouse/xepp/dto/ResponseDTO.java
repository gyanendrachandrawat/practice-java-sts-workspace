package com.bhouse.xepp.dto;

public class ResponseDTO {
    public String message;
    public Object data;
}
