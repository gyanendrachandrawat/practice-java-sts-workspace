package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.Address;
import com.bhouse.xepp.connector.model.SponseeMaster;
import com.bhouse.xepp.connector.model.SponsorshipRequest;


@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class SponseeMasterPojo {

    private int id;
    private String firstName;
    private String lastName;
    private String mobile;
    private String email;
    private String languagePreference;
    private int addressId;
    private String createdBy;
    private String updatedBy;
    private String requestTrackingId;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getFirstName() {
        return firstName;
    }

    public void setFirstName(String firstName) {
        this.firstName = firstName;
    }

    public String getLastName() {
        return lastName;
    }

    public void setLastName(String lastName) {
        this.lastName = lastName;
    }

    public String getMobile() {
        return mobile;
    }

    public void setMobile(String mobile) {
        this.mobile = mobile;
    }

    public String getEmail() {
        return email;
    }

    public void setEmail(String email) {
        this.email = email;
    }

    public String getLanguagePreference() {
        return languagePreference;
    }

    public void setLanguagePreference(String languagePreference) {
        this.languagePreference = languagePreference;
    }

    public int getAddressId() {
        return addressId;
    }

    public void setAddressId(int addressId) {
        this.addressId = addressId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public String getRequestTrackingId() {
        return requestTrackingId;
    }

    public void setRequestTrackingId(String requestTrackingId) {
        this.requestTrackingId = requestTrackingId;
    }

    public SponseeMaster convertToSponseeMasterModel(SponseeMaster smaster, SponseeMasterPojo smasterPojo){
        if(smaster == null){
            smaster = new SponseeMaster();
        }
        if(smasterPojo.getId() > 0){
            smaster.setId(smasterPojo.getId());
        }
        if(smasterPojo.getFirstName() != null && !smasterPojo.getFirstName().isEmpty()){
            smaster.setFirstName(smasterPojo.getFirstName());
        }
        if(smasterPojo.getLastName() != null && !smasterPojo.getLastName().isEmpty()){
            smaster.setLastName(smasterPojo.getLastName());
        }
        if(smasterPojo.getEmail() != null && !smasterPojo.getEmail().isEmpty()){
            smaster.setEmail(smasterPojo.getEmail());
        }
        if(smasterPojo.getLanguagePreference() != null && !smasterPojo.getLanguagePreference().isEmpty()){
            smaster.setLanguagePreference(smasterPojo.getLanguagePreference());
        }
        if(smasterPojo.getMobile() != null && !smasterPojo.getMobile().isEmpty()){
            smaster.setMobile(smasterPojo.getMobile());
        }
        if(smasterPojo.getAddressId() > 0){
            Address address = new Address();
            address.setId(smasterPojo.getAddressId());
            smaster.setAddress(address);
        }
        if(smasterPojo.getCreatedBy() != null && !smasterPojo.getCreatedBy().isEmpty()){
            smaster.setCreatedBy(smasterPojo.getCreatedBy());
            smaster.setCreatedDate(new Date());
        }
        if(smasterPojo.getUpdatedBy() != null && !smasterPojo.getUpdatedBy().isEmpty()){
            smaster.setUpdatedBy(smasterPojo.getUpdatedBy());
            smaster.setUpdatedDate(new Date());
        }
        if(smasterPojo.getRequestTrackingId() != null && !smasterPojo.getRequestTrackingId().isEmpty()){
            SponsorshipRequest sponsorshipRequest = new SponsorshipRequest();
            sponsorshipRequest.setRequestTrackingId(smasterPojo.getRequestTrackingId());
            smaster.setRequestTrackingId(sponsorshipRequest);
        }


        return smaster;
    }

}
