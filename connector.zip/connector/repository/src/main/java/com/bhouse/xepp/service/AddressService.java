package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.AddressRepository;
import com.bhouse.xepp.connector.model.Address;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.AddressPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.Date;
import java.util.List;
import java.util.Optional;

@Service
public class AddressService {

    @Autowired
    private AddressRepository addressRepository;

    public ResponseDTO saveAddress(AddressPojo addressPojo){
        System.out.println("Address Service --- save address....");
        ResponseDTO dto = new ResponseDTO();
        addressPojo.setCreatedDate(new Date());
        addressPojo.setUpdatedDate(new Date());
        Address address = addressRepository.save(addressPojo.convertToAddressModel(addressPojo));
        dto.message = "Address Saved Successfully.";
        dto.data = address;
        return  dto;
    }

    public ResponseDTO getAddressList(){
        ResponseDTO dto = new ResponseDTO();
        List<Address> address = addressRepository.findAll();
        dto.message = "Address List";
        dto.data = address;
        return dto;
    }

    public ResponseDTO getAddressById(int addressId){
        ResponseDTO dto = new ResponseDTO();
        Optional<Address> address = addressRepository.findById(addressId);
        dto.message = "Address details";

        dto.data = address;
        return dto;
    }

    public ResponseDTO updateAddress(){

        return null;
    }

    public ResponseDTO deleteAddressById(int addressId){
        System.out.println("In Delete Address BY ID service.");
        ResponseDTO dto = new ResponseDTO();
        //check if address exists in db, if exists delete
        Optional<Address> address = addressRepository.findById(addressId);
        if(address.isPresent()){
            addressRepository.delete(address.get());
            dto.message = "Address deleted successfully by id: " + addressId;
        }else {
            dto.message = "No Address found with given id: " + addressId;
        }
        return dto;
    }

}
