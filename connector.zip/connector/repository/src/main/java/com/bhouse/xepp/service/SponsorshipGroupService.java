package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.SponsorshipGroupRepository;
import com.bhouse.xepp.connector.model.SponsorshipGroup;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.SponsorshipGroupPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class SponsorshipGroupService {

    @Autowired
    private SponsorshipGroupRepository sponsorshipGroupRepository;

    public ResponseDTO saveSponsorshipGroup(SponsorshipGroupPojo sponsorshipGroupPojo){
        System.out.println("Save Sponsorship Group details..");
        ResponseDTO dto = new ResponseDTO();
        SponsorshipGroup sponsorshipGroup = sponsorshipGroupRepository.save(sponsorshipGroupPojo.convertToSponsorshipGroup(sponsorshipGroupPojo));
        dto.message = "Sponsorship Group saved successfully.";
        dto.data = sponsorshipGroup;
        return dto;
    }

    public ResponseDTO getSponsorshipGroupById(int sponsorshipGroupId){
        ResponseDTO dto = new ResponseDTO();
        Optional<SponsorshipGroup> sponsorshipGroup = sponsorshipGroupRepository.findById(sponsorshipGroupId);
        dto.message = "Sponsorship Group Details.";
        dto.data = sponsorshipGroup.get();
        return dto;
    }

    public ResponseDTO getSponsorshipGroupList(){
        ResponseDTO dto = new ResponseDTO();
        List<SponsorshipGroup> list = sponsorshipGroupRepository.findAll();
        dto.message = "Sponsoship Group List.";
        dto.data = list;
        return dto;
    }

    public ResponseDTO deleteSponsorshipGroupById(int sponsorshipGroupId){
        ResponseDTO dto = new ResponseDTO();
        //Check SponsorGroup entry exists in db then delete
        Optional<SponsorshipGroup> sponsorshipGroup = sponsorshipGroupRepository.findById(sponsorshipGroupId);
        if(sponsorshipGroup.isPresent()){
            sponsorshipGroupRepository.delete(sponsorshipGroup.get());
            dto.message = "Sponsorship Group deleted successfully.";
        }else{
            dto.message = "No Sponsorship Group exists with id: " + sponsorshipGroup;
        }
        return dto;
    }

}
