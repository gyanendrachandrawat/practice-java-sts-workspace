package com.bhouse.xepp.connector.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bhouse.xepp.connector.model.SponsorshipRequestLog;

public interface SponsorshipRequestLogRepository extends JpaRepository<SponsorshipRequestLog, Integer> {
}
