package com.bhouse.xepp.service;

import com.bhouse.xepp.connector.dao.BulkUploadFileTransferRepository;
import com.bhouse.xepp.connector.model.BulkUploadFileTransfer;
import com.bhouse.xepp.dto.ResponseDTO;
import com.bhouse.xepp.pojo.BulkUploadFileTransferPojo;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import java.util.List;
import java.util.Optional;

@Service
public class BulkUploadFileTransferService {

    @Autowired
    private BulkUploadFileTransferRepository bulkUploadFileTransferRepository;

    /**
     *
     * @param buftPojo
     * @return
     */
    public ResponseDTO saveBulkUploadFile(BulkUploadFileTransferPojo buftPojo){
        ResponseDTO dto = new ResponseDTO();
        BulkUploadFileTransfer buft = bulkUploadFileTransferRepository.save(buftPojo.convertToBulkUploadFileTransfer(null, buftPojo));
        dto.message = "BulkUploadFile details.";
        dto.data = buft;
        return dto;
    }

    /**
     *
     * @return
     */
    public ResponseDTO getBulkUploadFileTransferList(){
        ResponseDTO dto = new ResponseDTO();
        List<BulkUploadFileTransfer> buft = bulkUploadFileTransferRepository.findAll();
        dto.message = "List of File Transfers.";
        dto.data = buft;
        return dto;
    }

    /**
     *
     * @param fileTransferId
     * @return
     */
    public ResponseDTO getBulkUploadFileTransferById(int fileTransferId){
        ResponseDTO dto = new ResponseDTO();
        Optional<BulkUploadFileTransfer> buft = bulkUploadFileTransferRepository.findById(fileTransferId);
        if(buft.isPresent()){
            dto.message = "File transfer details.";
            dto.data = buft.get();
        }else{
            dto.message = "No details found with the id: " + fileTransferId;
        }
        return dto;
    }

    /**
     *
     * @param buftPojo
     * @return
     */
    public ResponseDTO updateBulkUploadFileTransfer(BulkUploadFileTransferPojo buftPojo){
        ResponseDTO dto = new ResponseDTO();
        Optional<BulkUploadFileTransfer> buft = bulkUploadFileTransferRepository.findById(buftPojo.getFileTransferId());
        if(buft.isPresent()){
            BulkUploadFileTransfer fileTransfer = bulkUploadFileTransferRepository.save(buftPojo.convertToBulkUploadFileTransfer(buft.get(), buftPojo));
            dto.message = "File transfer details.";
            dto.data = buft.get();
        }else{
            dto.message = "No details found with the id: " + buftPojo.getFileTransferId();
        }
        return dto;
    }

    /**
     *
     * @param fileTransferId
     * @return
     */
    public ResponseDTO deleteBulkUploadFileTransferById(int fileTransferId){
        ResponseDTO dto = new ResponseDTO();
        Optional<BulkUploadFileTransfer> buft = bulkUploadFileTransferRepository.findById(fileTransferId);
        if(buft.isPresent()){
            bulkUploadFileTransferRepository.delete(buft.get());
            dto.message = "File transfer detailed deleted successfully.";
        }else{
            dto.message = "No details found with the id: " + fileTransferId;
        }
        return dto;
    }
}
