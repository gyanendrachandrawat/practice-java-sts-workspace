package com.bhouse.xepp.connector.model;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import javax.persistence.*;
import java.util.Date;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
@Entity
@Table(name = "SPONSORSHIP_GROUP")
public class SponsorshipGroup {

    @Id
    @GeneratedValue(strategy = GenerationType.AUTO)
    @Column(name="GROUP_ID")
    private int id;

    @Column(name = "GROUP_NAME", length = 20)
    private String groupName;

    @Column(name = "GROUP_DESCRIPTION", length = 100)
    private String groupDescription;

//    @ManyToOne(targetEntity = SponsorMaster.class, cascade = CascadeType.ALL)
    @ManyToOne(targetEntity = SponsorMaster.class, cascade = CascadeType.MERGE)
    @JoinColumn(name = "SPONSOR_ID",nullable = false)
    private SponsorMaster sponsorId;

    @Column(name="CREATED_BY", length = 20, nullable = false)
    private String createdBy;

    @Column(name="CREATED_DATE", nullable = false)
    @Temporal(TemporalType.TIMESTAMP)
    private Date createdDate;

    @Column(name="UPDATED_BY", length = 20)
    private String updatedBy;

    @Column(name="UPDATED_DATE")
    @Temporal(TemporalType.TIMESTAMP)
    private Date updatedDate;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getGroupName() {
        return groupName;
    }

    public void setGroupName(String groupName) {
        this.groupName = groupName;
    }

    public String getGroupDescription() {
        return groupDescription;
    }

    public void setGroupDescription(String groupDescription) {
        this.groupDescription = groupDescription;
    }

    public SponsorMaster getSponsorId() {
        return sponsorId;
    }

    public void setSponsorId(SponsorMaster sponsorId) {
        this.sponsorId = sponsorId;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    public Date getCreatedDate() {
        return createdDate;
    }

    public void setCreatedDate(Date createdDate) {
        this.createdDate = createdDate;
    }

    public String getUpdatedBy() {
        return updatedBy;
    }

    public void setUpdatedBy(String updatedBy) {
        this.updatedBy = updatedBy;
    }

    public Date getUpdatedDate() {
        return updatedDate;
    }

    public void setUpdatedDate(Date updatedDate) {
        this.updatedDate = updatedDate;
    }
}
