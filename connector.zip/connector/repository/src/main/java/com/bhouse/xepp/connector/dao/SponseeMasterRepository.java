package com.bhouse.xepp.connector.dao;

import org.springframework.data.jpa.repository.JpaRepository;

import com.bhouse.xepp.connector.model.SponseeMaster;

public interface SponseeMasterRepository extends JpaRepository<SponseeMaster, Integer> {
}
