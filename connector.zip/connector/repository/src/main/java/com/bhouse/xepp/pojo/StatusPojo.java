package com.bhouse.xepp.pojo;

import lombok.AllArgsConstructor;
import lombok.Data;
import lombok.NoArgsConstructor;
import lombok.ToString;

import java.util.Date;

import com.bhouse.xepp.connector.model.Status;

@Data
@AllArgsConstructor
@NoArgsConstructor
@ToString
public class StatusPojo {

    private int id;
    private String name;
    private String category;
    private String description;
    private String createdBy;

    public int getId() {
        return id;
    }

    public void setId(int id) {
        this.id = id;
    }

    public String getName() {
        return name;
    }

    public void setName(String name) {
        this.name = name;
    }

    public String getCategory() {
        return category;
    }

    public void setCategory(String category) {
        this.category = category;
    }

    public String getDescription() {
        return description;
    }

    public void setDescription(String description) {
        this.description = description;
    }

    public String getCreatedBy() {
        return createdBy;
    }

    public void setCreatedBy(String createdBy) {
        this.createdBy = createdBy;
    }

    /**
     *
     * @param statusPojo
     * @return
     */
    public Status convertToStatusModel(Status status, StatusPojo statusPojo){
        if(status == null){
            status = new Status();
        }
        if(statusPojo.getId() > 0){
            status.setId(statusPojo.getId());
        }
        if(statusPojo.getCategory() != null && !statusPojo.getCategory().isEmpty()){
            status.setCategory(statusPojo.getCategory());
        }
        if(statusPojo.getCreatedBy() != null && !statusPojo.getCreatedBy().isEmpty()){
            status.setCreatedBy(statusPojo.getCreatedBy());
            status.setCreatedDate(new Date());
        }
        if(statusPojo.getDescription() != null && !statusPojo.getDescription().isEmpty()){
            status.setDescription(statusPojo.getDescription());
        }
        if(statusPojo.getName() != null && !statusPojo.getName().isEmpty()){
            status.setName(statusPojo.getName());
        }
        return status;
    }

}
