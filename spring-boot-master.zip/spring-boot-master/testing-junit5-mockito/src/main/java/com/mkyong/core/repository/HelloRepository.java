package com.mkyong.core.repository;

public interface HelloRepository {
    String get();
}
